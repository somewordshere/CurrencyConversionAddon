(function initializeContentEntry() {
  const M = CurrencyMessages;
  const SITE_PREFERENCES_KEY = "autoConvertSites";
  let settings = null;
  let settingsLoadPromise = null;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === M.CONTENT_READY) {
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === M.RUN_SITE_CONVERSION) {
      ensureSettingsLoaded()
        .then(() => runSiteConversion({ rememberSite: true }))
        .then((result) => {
          CurrencyPageUi.removePageConvertPrompt();
          showConversionResult(result);
          sendResponse(result);
        });
      return true;
    }

    if (message?.type === M.CLEAR_SITE_CONVERSION) {
      ensureSettingsLoaded()
        .then(() => clearSiteConversion({
          forgetSite: message.forgetSite,
          suppressPrompt: message.suppressPrompt
        }))
        .then(sendResponse);
      return true;
    }

    if (message?.type === M.SHOW_CONVERT_PROMPT) {
      ensureSettingsLoaded()
        .then(applySitePreference)
        .then(() => sendResponse({ ok: true }));
      return true;
    }

    if (message?.type === M.CONVERT_SELECTION) {
      ensureSettingsLoaded().then(convertCurrentSelection).then(sendResponse);
      return true;
    }
  });

  chrome.storage.onChanged.addListener(async (changes, areaName) => {
    if (
      areaName === "sync" &&
      (changes.enabled || changes.fromCurrency || changes.toCurrency)
    ) {
      settingsLoadPromise = loadSettings();
      await settingsLoadPromise;
    }
  });

  CurrencyPageUi.installSelectionListeners();
  settingsLoadPromise = loadSettings();

  function ensureSettingsLoaded() {
    return settingsLoadPromise || Promise.resolve();
  }

  async function loadSettings() {
    const result = await chrome.runtime.sendMessage({ type: M.GET_SETTINGS });
    if (!result?.ok) return;

    settings = result.settings;
    CurrencyDetector.resetPageCurrencyDetection();
    CurrencyPageConverter.configure(settings);
    CurrencyPageUi.configure({
      settings,
      runConversion: () => runSiteConversion({ rememberSite: true }),
      convertSelection: CurrencyPageConverter.convertSelectionText
    });

    CurrencyPageConverter.clearConversions();
    CurrencyPageUi.clearTransientUi();

    if (settings.enabled) {
      await applySitePreference();
    } else {
      CurrencyPageUi.removePageConvertPrompt();
    }
  }

  async function applySitePreference() {
    if (!settings?.enabled) {
      CurrencyPageUi.removePageConvertPrompt();
      return;
    }

    if (await isCurrentSiteRemembered()) {
      CurrencyPageUi.removePageConvertPrompt();
      const result = await runSiteConversion({ rememberSite: false });
      if (!result?.ok) showConversionResult(result);
    } else {
      CurrencyPageUi.showPageConvertPrompt();
    }
  }

  async function runSiteConversion({ rememberSite }) {
    const result = await CurrencyPageConverter.runSiteConversion();
    if (rememberSite && result?.ok && result.count > 0) {
      await setCurrentSiteRemembered(true);
    }
    return result;
  }

  async function clearSiteConversion({
    forgetSite = false,
    suppressPrompt = false
  } = {}) {
    CurrencyPageConverter.clearConversions();
    CurrencyPageUi.clearTransientUi();

    if (forgetSite) {
      await setCurrentSiteRemembered(false);
    }

    if (settings?.enabled && !suppressPrompt) {
      CurrencyPageUi.showPageConvertPrompt();
    } else {
      CurrencyPageUi.removePageConvertPrompt();
    }

    return { ok: true };
  }

  async function isCurrentSiteRemembered() {
    const siteKey = getCurrentSiteKey();
    if (!siteKey) return false;
    const stored = await chrome.storage.local.get(SITE_PREFERENCES_KEY);
    return stored[SITE_PREFERENCES_KEY]?.[siteKey] === true;
  }

  async function setCurrentSiteRemembered(remembered) {
    const siteKey = getCurrentSiteKey();
    if (!siteKey) return;

    const stored = await chrome.storage.local.get(SITE_PREFERENCES_KEY);
    const preferences = { ...(stored[SITE_PREFERENCES_KEY] || {}) };

    if (remembered) {
      preferences[siteKey] = true;
    } else {
      delete preferences[siteKey];
    }

    await chrome.storage.local.set({
      [SITE_PREFERENCES_KEY]: preferences
    });
  }

  function getCurrentSiteKey() {
    let hostname = window.location.hostname;

    if (!hostname) {
      const canonicalUrl = document.querySelector("link[rel='canonical']")?.href;
      if (canonicalUrl) {
        try {
          hostname = new URL(canonicalUrl, window.location.href).hostname;
        } catch (_error) {
          return null;
        }
      }
    }

    return hostname.toLowerCase().replace(/^www\./, "") || null;
  }

  async function convertCurrentSelection() {
    if (!settings?.enabled) {
      CurrencyPageUi.showToast("Turn the extension on first.");
      return { ok: false, error: "Extension is turned off." };
    }

    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) {
      CurrencyPageUi.showToast("Select a price first.");
      return { ok: false, error: "No selection found." };
    }

    const text = selection.toString().trim();
    const result = await CurrencyPageConverter.convertSelectionText(
      text,
      selection.anchorNode?.parentElement
    );
    CurrencyPageUi.showToast(
      result?.ok
        ? `${text} (${result.sourceCurrency}) = ${result.converted}`
        : result?.error || "Could not convert selection."
    );
    return result;
  }

  function showConversionResult(result) {
    if (result?.ok && result.count > 0) {
      const detected = settings.fromCurrency === "AUTO"
        ? ` Auto-detected: ${result.detectedCurrencies}.`
        : "";
      CurrencyPageUi.showToast(
        `Converted ${result.count} price${result.count === 1 ? "" : "s"}.${detected}`
      );
    } else {
      CurrencyPageUi.showToast(
        result?.error || "No confidently identified prices found on this page."
      );
    }
  }
})();
