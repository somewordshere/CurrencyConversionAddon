const enabledInput = document.getElementById("enabled");
const fromCurrencySelect = document.getElementById("fromCurrency");
const toCurrencySelect = document.getElementById("toCurrency");
const convertSiteButton = document.getElementById("convertSite");
const clearPageButton = document.getElementById("clearPage");
const clearSiteButton = document.getElementById("clearSite");
const statusNode = document.getElementById("status");
const currencyNames = new Intl.DisplayNames(["en"], { type: "currency" });
const M = CurrencyMessages;

initialize();

async function initialize() {
  const [currenciesResult, settingsResult] = await Promise.all([
    chrome.runtime.sendMessage({ type: M.GET_CURRENCIES }),
    chrome.runtime.sendMessage({ type: M.GET_SETTINGS })
  ]);

  if (!currenciesResult?.ok || !settingsResult?.ok) {
    setStatus("Could not load extension settings.");
    return;
  }

  populateCurrencySelect(fromCurrencySelect, ["AUTO", ...currenciesResult.currencies]);
  populateCurrencySelect(toCurrencySelect, currenciesResult.currencies);

  const settings = settingsResult.settings;
  enabledInput.checked = settings.enabled;
  fromCurrencySelect.value = settings.fromCurrency;
  toCurrencySelect.value = settings.toCurrency;

  enabledInput.addEventListener("change", handleSettingsChange);
  fromCurrencySelect.addEventListener("change", handleSettingsChange);
  toCurrencySelect.addEventListener("change", handleSettingsChange);
  convertSiteButton.addEventListener("click", handleConvertSiteClick);
  clearPageButton.addEventListener("click", handleClearPageClick);
  clearSiteButton.addEventListener("click", handleClearSiteClick);
}

async function handleSettingsChange() {
  await saveSettings();
}

async function handleConvertSiteClick() {
  await convertWholeSite();
}

async function handleClearSiteClick() {
  await clearWholeSite();
}

async function handleClearPageClick() {
  await clearCurrentPage();
}

function populateCurrencySelect(select, currencies) {
  select.innerHTML = "";

  for (const currency of currencies) {
    const option = document.createElement("option");
    option.value = currency;
    option.textContent = currency === "AUTO"
      ? "AUTO - Detect currency"
      : `${currency} - ${currencyNames.of(currency) || currency}`;
    select.appendChild(option);
  }
}

async function saveSettings() {
  if (fromCurrencySelect.value === toCurrencySelect.value) {
    setStatus("Choose two different currencies.");
    return;
  }

  const payload = {
    enabled: enabledInput.checked,
    fromCurrency: fromCurrencySelect.value,
    toCurrency: toCurrencySelect.value
  };
  const result = await chrome.runtime.sendMessage({
    type: M.UPDATE_SETTINGS,
    payload
  });

  if (!result?.ok) {
    setStatus("Could not save settings.");
    return;
  }

  setStatus(payload.enabled ? "Extension is on." : "Extension is off.");
  const pageResult = await sendToActivePage(
    payload.enabled ? M.SHOW_CONVERT_PROMPT : M.CLEAR_SITE_CONVERSION
  );

  if (!pageResult?.ok) {
    setStatus(pageResult?.error || "Reload this page once, then try again.");
  }
}

async function convertWholeSite() {
  if (!enabledInput.checked) {
    setStatus("Turn the extension on first.");
    return;
  }

  const result = await sendToActivePage(M.RUN_SITE_CONVERSION);
  if (!result?.ok) {
    setStatus(result?.error || "Could not convert this page.");
    return;
  }

  const detection = fromCurrencySelect.value === "AUTO" && result.detectedCurrency
    ? ` Detected page currency: ${result.detectedCurrency} (${result.detectionConfidence}).`
    : "";
  setStatus(
    `Converted ${result.count} price${result.count === 1 ? "" : "s"} on this page.${detection}`
  );
}

async function clearWholeSite() {
  const result = await sendToActivePage(M.CLEAR_SITE_CONVERSION, {
    forgetSite: true
  });
  if (!result?.ok) {
    setStatus(result?.error || "Could not clear this page.");
    return;
  }
  setStatus("Cleared conversion and forgot this website.");
}

async function clearCurrentPage() {
  const result = await sendToActivePage(M.CLEAR_SITE_CONVERSION, {
    forgetSite: false,
    suppressPrompt: true
  });
  if (!result?.ok) {
    setStatus(result?.error || "Could not clear this page.");
    return;
  }
  setStatus("Cleared conversion on this page. Website preference is unchanged.");
}

function setStatus(message) {
  statusNode.textContent = `CCP · ${message}`;
}

async function sendToActivePage(type, payload = {}) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return { ok: false, error: "No active tab found." };

  try {
    const response = await chrome.tabs.sendMessage(tab.id, {
      type,
      ...payload
    });
    return response || {
      ok: false,
      error: "The page did not respond. Reload it once, then try again."
    };
  } catch (_error) {
    return {
      ok: false,
      error: "Reload this page once, then try again. Chrome does not run extensions on its internal pages."
    };
  }
}
