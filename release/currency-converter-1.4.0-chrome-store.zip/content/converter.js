(function initializePageConverter(global) {
  const SKIP_TAGS = new Set([
    "SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "SELECT", "OPTION"
  ]);
  const PRICE_FRAGMENT_SELECTOR = [
    ".a-offscreen",
    ".a-price-symbol",
    ".a-price-whole",
    ".a-price-decimal",
    ".a-price-fraction"
  ].join(",");
  let settings = null;
  let activeRatesByBase = {};
  let conversionInProgress = false;

  function configure(nextSettings) {
    settings = nextSettings;
    activeRatesByBase = {};
  }

  async function runSiteConversion() {
    if (!settings?.enabled) {
      return { ok: false, error: "Extension is turned off." };
    }

    if (conversionInProgress) {
      return { ok: true, count: 0 };
    }

    conversionInProgress = true;

    try {
      clearConversions();
      const textPlans = collectTextNodes()
        .map((node) => ({
          node,
          matches: CurrencyDetector.findMatchesForContext(
            node.nodeValue,
            node.parentElement,
            settings
          )
        }))
        .filter((plan) => plan.matches.length);
      const splitPlans = collectSplitPricePlans();
      const bases = collectSourceCurrencies(textPlans, splitPlans);

      if (bases.size === 0) {
        const detection = CurrencyDetector.getPageCurrencyDetection();
        const sameAsTarget =
          settings.fromCurrency === "AUTO" &&
          detection.currency === settings.toCurrency;
        const autoDetectionFailed =
          settings.fromCurrency === "AUTO" &&
          (!detection.currency || detection.confidence === "low");

        return {
          ok: false,
          count: 0,
          detectedCurrency: detection.currency,
          detectionConfidence: detection.confidence,
          detectedCurrencies: CurrencyDetector.describeDetectedCurrencies(
            textPlans,
            splitPlans
          ),
          error: sameAsTarget
            ? `The detected page currency is already ${settings.toCurrency}. Choose a different target currency.`
            : autoDetectionFailed
              ? "Currency could not be detected confidently. Select the source currency manually."
              : settings.fromCurrency !== "AUTO"
                ? `Could not find the manually selected currency (${settings.fromCurrency}) on this page. Make sure the source currency is selected correctly.`
                : "No confidently identified prices found on this page."
        };
      }

      const rateResults = await Promise.all([...bases].map(ensureRates));
      const rateError = rateResults.find((result) => !result.ok);
      let count = 0;

      for (const plan of textPlans) count += applyTextPlan(plan);
      for (const plan of splitPlans) count += applySplitPlan(plan);

      return {
        ok: count > 0,
        count,
        detectedCurrency: CurrencyDetector.getPageCurrencyDetection().currency,
        detectionConfidence: CurrencyDetector.getPageCurrencyDetection().confidence,
        detectedCurrencies: CurrencyDetector.describeDetectedCurrencies(
          textPlans,
          splitPlans
        ),
        error: count === 0
          ? rateError?.error || "Prices were identified, but none could be converted."
          : undefined
      };
    } finally {
      conversionInProgress = false;
    }
  }

  async function convertSelectionText(selectedText, element) {
    if (!settings?.enabled) {
      return { ok: false, error: "Extension is turned off." };
    }

    const match = CurrencyDetector.findMatchesForContext(
      selectedText,
      element,
      settings,
      { selection: true }
    )[0];

    if (!match) {
      const error = settings.fromCurrency === "AUTO"
        ? "Could not confidently identify the selected currency."
        : `The selection does not look like ${settings.fromCurrency}.`;
      return { ok: false, error };
    }

    const ratesResult = await ensureRates(match.currency);
    if (!ratesResult?.ok) return ratesResult;

    return {
      ok: true,
      original: selectedText,
      sourceCurrency: match.currency,
      converted: convertAmount(match.amount, match.currency)
    };
  }

  function collectTextNodes() {
    if (!document.body) return [];

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue?.trim()) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (
          !parent ||
          SKIP_TAGS.has(parent.tagName) ||
          parent.closest(PRICE_FRAGMENT_SELECTOR) ||
          parent.closest("[aria-hidden='true']") ||
          parent.closest(
            "[data-currency-converted='true'], .currency-converter-toast, .currency-converter-selection-popup, .currency-converter-page-prompt"
          )
        ) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    return nodes;
  }

  function collectSplitPricePlans() {
    const plans = [];
    const elements = [...document.querySelectorAll("span, strong, b, p, div")]
      .sort((a, b) => getElementDepth(b) - getElementDepth(a));

    for (const element of elements) {
      if (
        element.childElementCount === 0 ||
        element.matches(PRICE_FRAGMENT_SELECTOR) ||
        element.closest("[aria-hidden='true']") ||
        element.closest("[data-currency-converted='true']") ||
        element.querySelector("[data-currency-converted='true']") ||
        plans.some((plan) => element.contains(plan.element))
      ) {
        continue;
      }

      const text = element.textContent?.trim();
      if (!text || text.length > 100) continue;

      const matches = CurrencyDetector.findMatchesForContext(text, element, settings);
      if (!matches.length || elementHasCompletePriceNode(element)) continue;
      plans.push({ element, matches: [matches[0]] });
    }

    return plans;
  }

  function elementHasCompletePriceNode(element) {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      if (walker.currentNode.parentElement?.closest(PRICE_FRAGMENT_SELECTOR)) {
        continue;
      }

      if (
        CurrencyDetector.findMatchesForContext(
          walker.currentNode.nodeValue || "",
          walker.currentNode.parentElement,
          settings
        ).length
      ) {
        return true;
      }
    }
    return false;
  }

  function getElementDepth(element) {
    let depth = 0;
    for (let current = element; current; current = current.parentElement) depth += 1;
    return depth;
  }

  function collectSourceCurrencies(...planGroups) {
    const bases = new Set();
    for (const plans of planGroups) {
      for (const plan of plans) {
        for (const match of plan.matches) {
          if (match.currency !== settings.toCurrency) bases.add(match.currency);
        }
      }
    }
    return bases;
  }

  async function ensureRates(baseCurrency) {
    if (activeRatesByBase[baseCurrency]?.[settings.toCurrency]) return { ok: true };

    const result = await chrome.runtime.sendMessage({
      type: CurrencyMessages.GET_RATES,
      baseCurrency
    });
    if (result?.ok) activeRatesByBase[baseCurrency] = result.rates;
    return result || { ok: false, error: "Could not load exchange rates." };
  }

  function applyTextPlan({ node, matches }) {
    if (!node.parentNode) return 0;
    const usable = matches.filter((match) =>
      activeRatesByBase[match.currency]?.[settings.toCurrency]
    );
    if (!usable.length) return 0;

    const text = node.nodeValue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;

    for (const match of usable) {
      fragment.append(document.createTextNode(text.slice(lastIndex, match.index)));
      fragment.append(buildConvertedNode(match));
      lastIndex = match.index + match.raw.length;
    }

    fragment.append(document.createTextNode(text.slice(lastIndex)));
    node.parentNode.replaceChild(fragment, node);
    return usable.length;
  }

  function applySplitPlan({ element, matches }) {
    if (
      !element.isConnected ||
      element.closest("[data-currency-converted='true']") ||
      element.querySelector("[data-currency-converted='true']")
    ) {
      return 0;
    }

    const match = matches.find((candidate) =>
      activeRatesByBase[candidate.currency]?.[settings.toCurrency]
    );
    if (!match) return 0;

    const badge = document.createElement("span");
    badge.dataset.currencyConverted = "true";
    badge.dataset.currencyAppended = "true";
    badge.className = "currency-converter-badge";
    badge.textContent = ` ≈ ${convertAmount(match.amount, match.currency)}`;
    styleConvertedPrice(badge);
    element.appendChild(badge);
    return 1;
  }

  function buildConvertedNode(match) {
    const wrapper = document.createElement("span");
    wrapper.dataset.currencyConverted = "true";
    wrapper.dataset.sourceCurrency = match.currency;
    wrapper.className = "currency-converter-wrapper";

    const original = document.createElement("span");
    original.className = "currency-converter-original";
    original.textContent = match.raw;

    const converted = document.createElement("span");
    converted.className = "currency-converter-badge";
    converted.textContent = ` ≈ ${convertAmount(match.amount, match.currency)}`;
    styleConvertedPrice(converted);
    wrapper.append(original, converted);
    return wrapper;
  }

  function styleConvertedPrice(element) {
    Object.assign(element.style, {
      color: "#15803d",
      fontWeight: "700"
    });
  }

  function convertAmount(amount, baseCurrency) {
    const rate = activeRatesByBase[baseCurrency]?.[settings.toCurrency];
    const locale = CurrencyCatalog.CURRENCY_META[settings.toCurrency]?.locale || "en-US";
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency: settings.toCurrency,
      maximumFractionDigits: 2
    }).format(amount * rate);
  }

  function clearConversions() {
    for (const wrapper of document.querySelectorAll("[data-currency-converted='true']")) {
      if (wrapper.dataset.currencyAppended === "true") {
        wrapper.remove();
      } else {
        wrapper.replaceWith(
          document.createTextNode(
            wrapper.querySelector(".currency-converter-original")?.textContent || ""
          )
        );
      }
    }
  }

  global.CurrencyPageConverter = Object.freeze({
    configure,
    runSiteConversion,
    convertSelectionText,
    clearConversions
  });
})(globalThis);
