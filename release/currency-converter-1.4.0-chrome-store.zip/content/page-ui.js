(function initializePageUi(global) {
  let settings = null;
  let pageConvertPrompt = null;
  let selectionPopup = null;
  let pendingSelectionText = "";
  let runConversion = null;
  let convertSelection = null;

  function configure(options) {
    settings = options.settings;
    runConversion = options.runConversion;
    convertSelection = options.convertSelection;
  }

  function installSelectionListeners() {
    document.addEventListener("mouseup", handleTextSelection);
    document.addEventListener("keyup", handleKeyboardSelection);
    document.addEventListener("mousedown", handleOutsideSelectionPopup);
    window.addEventListener("scroll", removeSelectionPopup, true);
  }

  function showPageConvertPrompt() {
    if (
      pageConvertPrompt ||
      !settings?.enabled ||
      !document.body ||
      window.top !== window
    ) {
      return;
    }

    pageConvertPrompt = document.createElement("button");
    pageConvertPrompt.type = "button";
    pageConvertPrompt.className = "currency-converter-page-prompt";
    pageConvertPrompt.textContent = "CCP · Convert all currencies";
    Object.assign(pageConvertPrompt.style, {
      position: "fixed",
      top: "16px",
      right: "16px",
      zIndex: "2147483647",
      border: "0",
      borderRadius: "8px",
      padding: "10px 15px",
      background: "#2563eb",
      color: "#ffffff",
      font: "700 13px/1.2 system-ui, sans-serif",
      cursor: "pointer",
      boxShadow: "0 6px 16px rgba(0, 0, 0, 0.25)"
    });

    pageConvertPrompt.addEventListener("click", handleConvertAllClick);
    document.body.appendChild(pageConvertPrompt);
  }

  async function handleConvertAllClick() {
    pageConvertPrompt.disabled = true;
    pageConvertPrompt.textContent = "CCP · Converting…";
    const result = await runConversion();
    if (!pageConvertPrompt) return;

    if (result?.ok) {
      const detected = result.detectedCurrency
        ? ` · Detected ${result.detectedCurrency}`
        : "";
      pageConvertPrompt.textContent =
        `CCP · Converted ${result.count} price${result.count === 1 ? "" : "s"}${detected}`;
      pageConvertPrompt.style.background = "#0f766e";
      window.setTimeout(removePageConvertPrompt, 6000);
    } else {
      pageConvertPrompt.disabled = false;
      pageConvertPrompt.textContent = "CCP · Try again";
      pageConvertPrompt.style.background = "#b91c1c";
      showToast(
        result?.error ||
        "Currency could not be detected confidently. Select the source currency manually."
      );
    }
  }

  function removePageConvertPrompt() {
    pageConvertPrompt?.remove();
    pageConvertPrompt = null;
  }

  function handleTextSelection(event) {
    if (!selectionPopup?.contains(event.target)) {
      window.setTimeout(showSelectionPopup, 0);
    }
  }

  function handleKeyboardSelection(event) {
    if (event.key === "Shift" || event.shiftKey) {
      window.setTimeout(showSelectionPopup, 0);
    }
  }

  function showSelectionPopup() {
    removeSelectionPopup();
    if (!settings?.enabled) return;

    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return;

    const selectedText = selection.toString().trim();
    const match = CurrencyDetector.findMatchesForContext(
      selectedText,
      selection.anchorNode?.parentElement,
      settings,
      { selection: true }
    )[0];
    if (!match) return;

    const rect = selection.getRangeAt(0).getBoundingClientRect();
    if (!rect.width && !rect.height) return;

    pendingSelectionText = selectedText;
    selectionPopup = document.createElement("button");
    selectionPopup.type = "button";
    selectionPopup.className = "currency-converter-selection-popup";
    selectionPopup.textContent = "CCP · Convert";
    selectionPopup.title = `CCP · Convert ${match.currency} to ${settings.toCurrency}`;
    Object.assign(selectionPopup.style, {
      position: "fixed",
      left: "0",
      top: "0",
      zIndex: "2147483647",
      border: "0",
      borderRadius: "8px",
      padding: "7px 11px",
      background: "#2563eb",
      color: "#ffffff",
      font: "600 13px/1.2 system-ui, sans-serif",
      cursor: "pointer",
      boxShadow: "0 6px 20px rgba(0, 0, 0, 0.25)"
    });
    selectionPopup.addEventListener("mousedown", (event) => {
      event.preventDefault();
      event.stopPropagation();
    });
    selectionPopup.addEventListener("click", handleConvertSelectionClick);
    document.body.appendChild(selectionPopup);

    const popupRect = selectionPopup.getBoundingClientRect();
    const left = Math.min(
      Math.max(8, rect.left + rect.width / 2 - popupRect.width / 2),
      window.innerWidth - popupRect.width - 8
    );
    const preferredTop = rect.bottom + 8;
    const top = preferredTop + popupRect.height <= window.innerHeight
      ? preferredTop
      : Math.max(8, rect.top - popupRect.height - 8);
    selectionPopup.style.left = `${left}px`;
    selectionPopup.style.top = `${top}px`;
  }

  async function handleConvertSelectionClick(event) {
    event.preventDefault();
    event.stopPropagation();
    if (!selectionPopup || !pendingSelectionText) return;

    selectionPopup.disabled = true;
    selectionPopup.textContent = "CCP · Converting…";
    const selection = window.getSelection();
    const result = await convertSelection(
      pendingSelectionText,
      selection?.anchorNode?.parentElement
    );
    if (!selectionPopup) return;

    selectionPopup.disabled = false;
    selectionPopup.textContent = result?.ok
      ? `CCP · ${result.sourceCurrency} → ${result.converted}`
      : `CCP · ${result?.error || "Could not convert"}`;
    selectionPopup.style.background = result?.ok ? "#0f766e" : "#b91c1c";
    window.setTimeout(removeSelectionPopup, 3500);
  }

  function handleOutsideSelectionPopup(event) {
    if (selectionPopup && !selectionPopup.contains(event.target)) {
      removeSelectionPopup();
    }
  }

  function removeSelectionPopup() {
    selectionPopup?.remove();
    selectionPopup = null;
    pendingSelectionText = "";
  }

  function showToast(message) {
    document.querySelector(".currency-converter-toast")?.remove();
    const toast = document.createElement("div");
    toast.className = "currency-converter-toast";
    toast.textContent = `CCP · ${message}`;
    Object.assign(toast.style, {
      position: "fixed",
      right: "16px",
      top: "16px",
      zIndex: "2147483647",
      background: "#111827",
      color: "#fff",
      padding: "10px 14px",
      borderRadius: "10px",
      fontSize: "13px",
      fontFamily: "system-ui, sans-serif",
      boxShadow: "0 10px 30px rgba(0,0,0,0.25)"
    });
    document.body.appendChild(toast);
    window.setTimeout(() => toast.remove(), 6000);
  }

  function clearTransientUi() {
    removeSelectionPopup();
    document.querySelectorAll(".currency-converter-toast").forEach((node) => node.remove());
  }

  global.CurrencyPageUi = Object.freeze({
    configure,
    installSelectionListeners,
    showPageConvertPrompt,
    removePageConvertPrompt,
    showToast,
    clearTransientUi
  });
})(globalThis);
