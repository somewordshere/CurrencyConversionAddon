(function initializeRateService(global) {
  const { CURRENCY_CODES } = global.CurrencyCatalog;
  let cacheWriteQueue = Promise.resolve();

  async function getRates(baseCurrency) {
    try {
      if (!CURRENCY_CODES.includes(baseCurrency)) {
        return { ok: false, error: `Unsupported source currency: ${baseCurrency}.` };
      }

      const { ratesCache } = await chrome.storage.local.get("ratesCache");
      const today = new Date().toISOString().slice(0, 10);
      const cachedBase = ratesCache?.version === 2 && ratesCache.date === today
        ? ratesCache.bases?.[baseCurrency]
        : null;

      if (cachedBase?.rates && Object.keys(cachedBase.rates).length > 1) {
        return {
          ok: true,
          rates: cachedBase.rates,
          date: cachedBase.rateDate || today,
          cached: true
        };
      }

      const quotes = CURRENCY_CODES.filter((currency) => currency !== baseCurrency);
      const url = `https://api.frankfurter.dev/v2/rates?base=${encodeURIComponent(baseCurrency)}&quotes=${quotes.join(",")}`;
      const response = await fetch(url);

      if (!response.ok) {
        return {
          ok: false,
          error: `Could not fetch exchange rates (${response.status}).`
        };
      }

      const parsed = parseRatesResponse(await response.json());

      if (!Object.keys(parsed.rates).length) {
        return { ok: false, error: "The exchange-rate service returned no usable rates." };
      }

      const baseCache = {
        rateDate: parsed.date || today,
        rates: {
          ...parsed.rates,
          [baseCurrency]: 1
        }
      };

      await saveBaseRates(baseCurrency, baseCache, today);
      return {
        ok: true,
        rates: baseCache.rates,
        date: baseCache.rateDate,
        cached: false
      };
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : "Could not load exchange rates."
      };
    }
  }

  async function saveBaseRates(baseCurrency, baseCache, today) {
    cacheWriteQueue = cacheWriteQueue.catch(() => {}).then(async () => {
      const { ratesCache } = await chrome.storage.local.get("ratesCache");
      const existingBases = ratesCache?.version === 2 && ratesCache.date === today
        ? ratesCache.bases || {}
        : {};

      await chrome.storage.local.set({
        ratesCache: {
          version: 2,
          date: today,
          bases: {
            ...existingBases,
            [baseCurrency]: baseCache
          }
        }
      });
    });

    await cacheWriteQueue;
  }

  function parseRatesResponse(data) {
    if (Array.isArray(data)) {
      const rates = {};
      let date = null;

      for (const item of data) {
        if (item?.quote && Number.isFinite(item.rate)) {
          rates[item.quote] = item.rate;
          date ||= item.date || null;
        }
      }

      return { rates, date };
    }

    if (data?.rates && typeof data.rates === "object") {
      return { rates: data.rates, date: data.date || null };
    }

    return { rates: {}, date: null };
  }

  global.CurrencyRateService = Object.freeze({
    getRates,
    parseRatesResponse
  });
})(globalThis);
