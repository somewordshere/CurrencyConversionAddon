importScripts(
  "../shared/currencies.js",
  "../shared/messages.js",
  "rates.js"
);

const DEFAULT_SETTINGS = {
  enabled: false,
  fromCurrency: "AUTO",
  toCurrency: "EUR"
};

const M = CurrencyMessages;

chrome.runtime.onInstalled.addListener(async function initializeExtension() {
  const stored = await chrome.storage.sync.get(Object.keys(DEFAULT_SETTINGS));
  await chrome.storage.sync.set({ ...DEFAULT_SETTINGS, ...stored });

  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({
    id: "convert-selection",
    title: "Convert selected currency",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener(async function handleContextMenuClick(info, tab) {
  if (info.menuItemId !== "convert-selection" || !isSupportedTab(tab)) {
    return;
  }

  try {
    await chrome.tabs.sendMessage(tab.id, { type: M.CONVERT_SELECTION });
  } catch (error) {
    console.info(
      "Currency Converter Pro could not access this page. Reload the page and try again.",
      error
    );
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === M.GET_SETTINGS) {
    getSettings().then(sendResponse);
    return true;
  }

  if (message?.type === M.UPDATE_SETTINGS) {
    updateSettings(message.payload).then(sendResponse);
    return true;
  }

  if (message?.type === M.GET_RATES) {
    CurrencyRateService.getRates(message.baseCurrency).then(sendResponse);
    return true;
  }

  if (message?.type === M.GET_CURRENCIES) {
    sendResponse({ ok: true, currencies: CurrencyCatalog.CURRENCY_CODES });
  }
});

async function getSettings() {
  const settings = await chrome.storage.sync.get(Object.keys(DEFAULT_SETTINGS));
  return { ok: true, settings: { ...DEFAULT_SETTINGS, ...settings } };
}

async function updateSettings(payload) {
  const current = await chrome.storage.sync.get(Object.keys(DEFAULT_SETTINGS));
  const settings = { ...DEFAULT_SETTINGS, ...current, ...payload };
  await chrome.storage.sync.set(settings);
  return { ok: true, settings };
}

function isSupportedTab(tab) {
  return Boolean(
    tab?.id &&
    tab.url &&
    (
      tab.url.startsWith("http://") ||
      tab.url.startsWith("https://") ||
      tab.url.startsWith("file://")
    )
  );
}
